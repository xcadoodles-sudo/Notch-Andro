package com.nusa.notch

import android.app.*
import android.bluetooth.BluetoothDevice
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.*
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("nusa", Context.MODE_PRIVATE)
    fun todos(c: Context): List<String> = sp(c).getString("todos", "")!!.split("\n").filter { it.isNotBlank() }
    fun add(c: Context, t: String) =
        sp(c).edit().putString("todos", (todos(c) + t.replace("\n", " ")).joinToString("\n")).apply()
    fun remove(c: Context, i: Int) =
        sp(c).edit().putString("todos", todos(c).filterIndexed { j, _ -> j != i }.joinToString("\n")).apply()
}

class NotchService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var head: TextView
    private lateinit var body: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private val h = Handler(Looper.getMainLooper())
    private var expanded = false
    private var tab = 0
    private var flash: String? = null
    private var titleText: TextView? = null
    private var timerText: TextView? = null
    private var timer: CountDownTimer? = null
    private var left = 25 * 60_000L
    private var running = false
    private val clearFlash = Runnable { flash = null; tick() }
    private val tickR = object : Runnable { override fun run() { tick(); h.postDelayed(this, 1000) } }

    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            val name = (try { d?.name } catch (e: SecurityException) { null }) ?: "Perangkat"
            if (i.action == BluetoothDevice.ACTION_ACL_CONNECTED) {
                val bat = try { d!!.javaClass.getMethod("getBatteryLevel").invoke(d) as Int } catch (e: Exception) { -1 }
                flash("🎧 $name terhubung" + if (bat >= 0) " • $bat%" else "")
            } else flash("🎧 $name terputus")
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("notch", "Notch", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "notch").setContentTitle("Notch aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        head = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; setPadding(dp(16), dp(5), dp(16), dp(5))
            setOnClickListener { expanded = !expanded; tab = 0; applySize(); buildBody() }
        }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(14)); visibility = View.GONE
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; minimumWidth = dp(200)
            background = GradientDrawable().apply {
                setColor(Color.BLACK); val r = dp(22).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
            addView(head); addView(body)
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }
        wm.addView(root, lp)

        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED); addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(btReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(btReceiver, f)
        NotifListener.onPosted = { flash(it) }
        h.post(tickR)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null); timer?.cancel()
        NotifListener.onPosted = null
        try { unregisterReceiver(btReceiver) } catch (e: Exception) {}
        try { wm.removeView(root) } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fmt(ms: Long) = "%02d:%02d".format(ms / 60000, ms / 1000 % 60)
    private fun tv(s: String) = TextView(this).apply { text = s; setTextColor(Color.WHITE); textSize = 14f; setPadding(0, dp(6), 0, dp(6)) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        setBackgroundColor(0x33FFFFFF); setOnClickListener { f() }
    }

    private fun flash(m: String) {
        flash = m; h.removeCallbacks(clearFlash); h.postDelayed(clearFlash, 4000); tick()
    }

    private fun applySize() {
        lp.width = if (expanded) dp(460) else WindowManager.LayoutParams.WRAP_CONTENT
        body.visibility = if (expanded) View.VISIBLE else View.GONE
        wm.updateViewLayout(root, lp)
    }

    private fun controller(): MediaController? = try {
        val l = (getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager)
            .getActiveSessions(ComponentName(this, NotifListener::class.java))
        l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
    } catch (e: SecurityException) { null }

    private fun toggleTimer() {
        if (running) { timer?.cancel(); running = false; return }
        running = true
        timer = object : CountDownTimer(left, 1000) {
            override fun onTick(ms: Long) { left = ms }
            override fun onFinish() { running = false; left = 25 * 60_000L; flash("Pomodoro selesai ☕"); buildBody() }
        }.start()
    }

    private fun resetTimer() { timer?.cancel(); running = false; left = 25 * 60_000L }

    private fun tick() {
        val c = controller()
        val title = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val artist = c?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        head.text = flash ?: when {
            running -> "⏱ ${fmt(left)}"
            title != null -> "♪ $title"
            else -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        }
        titleText?.text = if (title != null) "$title\n${artist ?: ""}" else "Tidak ada musik yang diputar"
        timerText?.text = fmt(left)
    }

    private fun buildBody() {
        body.removeAllViews(); titleText = null; timerText = null
        if (!expanded) return
        val tabs = LinearLayout(this)
        listOf("Musik", "Timer", "Tugas", "Notif").forEachIndexed { i, n ->
            tabs.addView(btn(if (i == tab) "● $n" else n) { tab = i; buildBody() })
        }
        body.addView(tabs)
        when (tab) {
            0 -> {
                titleText = tv(""); body.addView(titleText)
                val r = LinearLayout(this)
                r.addView(btn("⏮") { controller()?.transportControls?.skipToPrevious() })
                r.addView(btn("⏯") {
                    controller()?.let { c ->
                        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                        else c.transportControls.play()
                    }
                })
                r.addView(btn("⏭") { controller()?.transportControls?.skipToNext() })
                body.addView(r)
            }
            1 -> {
                timerText = tv("").apply { textSize = 28f }; body.addView(timerText)
                val r = LinearLayout(this)
                r.addView(btn(if (running) "Jeda" else "Mulai") { toggleTimer(); buildBody() })
                r.addView(btn("Reset") { resetTimer(); buildBody() })
                body.addView(r)
            }
            2 -> {
                val items = Store.todos(this)
                if (items.isEmpty()) body.addView(tv("Belum ada tugas — tambah dari app"))
                items.forEachIndexed { i, t -> body.addView(btn("☐ $t") { Store.remove(this, i); buildBody() }) }
            }
            3 -> {
                if (NotifListener.recent.isEmpty()) body.addView(tv("Belum ada notifikasi"))
                NotifListener.recent.forEach { body.addView(tv(it)) }
            }
        }
        tick()
    }
}
