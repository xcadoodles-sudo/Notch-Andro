package com.nusa.notch

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    companion object {
        val recent = ArrayDeque<String>()
        var onPosted: ((String) -> Unit)? = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (sbn.packageName == packageName || (n.flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
            n.category == Notification.CATEGORY_TRANSPORT) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ex: Exception) { sbn.packageName }
        val line = "$app • $title" + if (text.isNotEmpty()) ": $text" else ""
        recent.addFirst(line)
        while (recent.size > 5) recent.removeLast()
        onPosted?.invoke(line)
    }
}
