package com.nusa.notch

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        fun add(t: String, f: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        add("1. Izin tampil di atas app lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        add("2. Akses notifikasi (musik & notif)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        add("3. Izin Bluetooth & notifikasi") {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        add("4. Bebaskan dari hemat baterai") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        add("▶ Nyalakan notch") { startForegroundService(Intent(this, NotchService::class.java)) }
        add("■ Matikan notch") { stopService(Intent(this, NotchService::class.java)) }
        val et = EditText(this).apply { hint = "Tugas baru" }
        col.addView(et)
        add("Tambah tugas") {
            if (et.text.isNotBlank()) { Store.add(this, et.text.toString()); et.setText("") }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
